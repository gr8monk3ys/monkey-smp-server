Golden fixture for the patch rules. Not a mod or a datapack.
